<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="dungeon tileset calciumtrice" tilewidth="16" tileheight="16" tilecount="1050" columns="30">
 <image source="../../../../../../University/2nd_year/SEPR/Grafika/kafelki/dungeon tileset calciumtrice.png" width="480" height="560"/>
</tileset>
