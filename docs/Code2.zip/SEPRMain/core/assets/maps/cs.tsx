<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="cs" tilewidth="32" tileheight="32" tilecount="225" columns="15">
 <image source="cs.png" width="480" height="480"/>
 <tile id="49">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="68">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="77">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="78">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="79">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="80">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="85">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="94">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="95">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="98">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="99">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="101">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="106">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="107">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="108">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="116">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="121">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="128">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="131">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="132">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="136">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="137">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="138">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="141">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="142">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="143">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="151">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="152">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="153">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="156">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="157">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="158">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="167">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="168">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="169">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="170">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="171">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="172">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="173">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="174">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="175">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="176">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="182">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="183">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="184">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="185">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="187">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="188">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="189">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="190">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="191">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="200">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="201">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="202">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="203">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="215">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="216">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="217">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
