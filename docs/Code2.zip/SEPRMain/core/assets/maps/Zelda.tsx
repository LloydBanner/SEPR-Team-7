<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Zelda" tilewidth="16" tileheight="16" spacing="1" tilecount="1519" columns="49">
 <image source="2edca995729999be6ef9f0d779c71ae5.png" width="837" height="540"/>
 <tile id="0">
  <properties>
   <property name="blocked" value=""/>
  </properties>
  <objectgroup draworder="index">
   <object id="1" x="5" y="6" width="6.25" height="4.75">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
  </animation>
 </tile>
 <tile id="250">
  <objectgroup draworder="index">
   <object id="2" x="5.25" y="4.75" width="6.5" height="8.5">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
</tileset>
