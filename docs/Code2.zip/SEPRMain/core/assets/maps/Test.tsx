<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="Test" tilewidth="32" tileheight="32" tilecount="483" columns="23">
 <image source="33cu7fc.png" width="736" height="672"/>
 <tile id="1">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="3">
  <animation>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="120"/>
   <frame tileid="5" duration="120"/>
  </animation>
 </tile>
 <tile id="23">
  <properties>
   <property name="blocked" value=""/>
  </properties>
  <objectgroup draworder="index">
   <object id="1" x="19.6736" y="16.8036" width="3.76685" height="5.69558" rotation="-248.749">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
 <tile id="24">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="276">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="277">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="279">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="280">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="353">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
