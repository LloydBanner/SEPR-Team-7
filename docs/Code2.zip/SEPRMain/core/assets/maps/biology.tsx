<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="biology" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="biology.png" width="384" height="384"/>
 <tile id="28">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="68">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="78">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="79">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="87">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="88">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="96">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="97">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="98">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
