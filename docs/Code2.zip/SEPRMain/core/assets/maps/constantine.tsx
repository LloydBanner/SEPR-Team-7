<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="constantine" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="constantine.png" width="384" height="384"/>
 <tile id="1">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="95">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="105">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="106">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="116">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
