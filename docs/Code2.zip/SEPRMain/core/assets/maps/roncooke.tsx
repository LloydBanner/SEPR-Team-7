<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="roncooke" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="ron cooke-1.png.png" width="384" height="384"/>
 <tile id="31">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="96">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="104">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="123">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
