<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="centralhall" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="centralhall.png" width="384" height="384"/>
 <tile id="28">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="85">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="97">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="102">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="103">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="104">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="111">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="112">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
